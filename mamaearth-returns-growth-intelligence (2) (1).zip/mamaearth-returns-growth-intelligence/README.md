# Mamaearth Returns & Growth Intelligence Pipeline

An end-to-end capstone pipeline for order returns and revenue analysis. The
repository keeps the supplied CSVs unchanged, loads them into SQLite, cleans
and analyzes the database with pandas, creates the two requested charts, and
passes the computed findings to an OpenAI-compatible model for a constrained
GenAI narrative.

> Revenue in this project means order value after discounts. Returned order
> value is reported separately from retained revenue. The supplied data has no
> product costs, shipping costs, or refund amounts, so it cannot support a
> profit or margin calculation.

## Repository map

```text
.
├── README.md
├── requirements.txt
├── scripts/
│   └── rebuild_database.sh
├── sql/
│   ├── schema.sql
│   ├── seed_data.sql
│   └── reports.sql
├── data/
│   ├── customers.csv             # supplied source data; do not edit
│   ├── products.csv              # supplied source data; do not edit
│   └── orders.csv                # supplied source data; do not edit
├── analysis/
│   ├── clean_and_eda.py
│   └── visualize.py
├── visualizations/
│   ├── return_rate_by_payment.png
│   └── monthly_revenue_trend.png
└── narrator/
    ├── findings.json
    └── generate_narrative.py
```

`data/mamaearth.db` is created locally by SQLite and is intentionally not
committed. The source CSVs remain the system of record; all cleaning happens
in the Python analysis step.

## Run the pipeline

Run every command from the repository root. Python 3.10+ and the SQLite
command-line program are required.

### 1. Install Python dependencies

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

On Windows PowerShell, activate with `.venv\Scripts\Activate.ps1`.

### 2. Build the SQLite database and run the SQL reports

```bash
bash scripts/rebuild_database.sh
```

The script builds a temporary database from `schema.sql`, imports the three
unchanged CSVs with `seed_data.sql`, runs `reports.sql`, checks the expected
row counts, revenue, missing values, loyalty tiers, foreign keys, and database
integrity, then replaces `data/mamaearth.db` only if every check passes.
`seed_data.sql` uses SQLite's CSV import command and converts blank
`discount_pct` and `rating` cells to SQL `NULL`. The source CSV files must stay
at the paths shown above.

`reports.sql` adds and fills the `loyalty_tier` column in its final section, so
run it once per freshly loaded database. To rerun the full SQL layer, run the
rebuild script again; it starts from a fresh database each time.

### 3. Clean and analyze with pandas

```bash
python analysis/clean_and_eda.py
```

The Python layer reads the SQLite tables, then:

- removes duplicate orders using customer, product, date, quantity, discount,
  payment method, rating, and return status (excluding `order_id`);
- standardizes payment-method casing;
- converts blank discount and rating values to missing values, then fills them
  with their respective cleaned-data medians;
- keeps unusual quantities in the analysis and flags them instead of silently
  dropping or capping them;
- computes order-level discounted value, retained revenue, and returned value.

This step writes the computed metrics and breakdowns to
`narrator/findings.json`. That JSON is the only numeric input to the GenAI
narrator.

### 4. Create the requested visualizations

```bash
python analysis/visualize.py
```

The charts use the same cleaned orders and calculations as the EDA layer and
write the two PNGs under `visualizations/`.

### 5. Generate the AI narrative

Set either `OPENAI_API_KEY` (for the standard OpenAI API) or configure the
Replit OpenAI AI Integration, then run:

```bash
python narrator/generate_narrative.py
```

Optional settings:

```bash
export OPENAI_BASE_URL="https://api.openai.com/v1"
export NARRATIVE_MODEL="gpt-5-mini"
```

The script reads the metrics produced in step 4 and adds a `narrative` object
to `narrator/findings.json`. It asks the model for qualitative commentary and
references to existing metric keys; it rejects unsupported metric references
and numerical claims in generated prose. The model does not calculate or
replace the analysis results. If the model request fails, the script exits
with an error and leaves the verified metrics intact.

Replit AI Integration calls are billed to your Replit credits. If running
outside Replit, use your own OpenAI API credentials and review the provider's
charges.

## Data flow and integrity

```text
unchanged CSVs
    └── SQLite tables + SQL reports
          └── pandas cleaning and verified metrics
                ├── requested charts
                └── findings.json → GenAI narrative → updated findings.json
```

The SQL import creates the raw relational store. Python reads that store,
performs documented cleaning, and computes all metric values. The narrator
receives those verified values from `findings.json`; it is not given the raw
CSV files or allowed to invent replacement numbers.

The payment-method chart uses cleaned order counts as the denominator.
Monthly retained revenue excludes returned orders and uses selling price after
discounts. Returned value is the discounted value of returned orders. These
are revenue measures, not margin estimates.
